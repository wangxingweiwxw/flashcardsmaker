---
name: pdf-to-kdf-flashcards
description: This skill should be used when a user asks to turn a PDF, textbook chapter, lecture handout, or technical paper into a validated KDF v1 knowledge-flashcard JSON deck that can be imported into the Knowledge Flashcard Generator or exported to Anki.
agent_created: true
version: 1.0.0
---

# PDF to KDF flashcards

Convert a text-based PDF into a reviewable Knowledge Deck Format (KDF) v1 flashcard package. Keep source provenance on every generated card and publish no AI-generated card without an explicit review decision.

## Workflow

1. Inspect the PDF with `scripts/pdf_to_kdf.py extract <pdf> <output-dir>`.
2. Read `references/kdf-card-generation.md` before creating cards.
3. Select the intended deck title, audience, language, card type, and target number of cards. Default to `basic`, `draft`, and 12 cards for a first pass.
4. Generate candidate cards from the extracted chunks. Use only claims that are supported by a chunk. Set each card's `source.type` to `pdf`, `source.documentId` to the source filename, and `source.locator` to the page range.
5. Save candidates as a KDF v1 JSON deck and run `scripts/pdf_to_kdf.py validate <deck.json>`.
6. Present the draft deck for review. Change only approved cards from `draft` to `published`.
7. Build an importable package with `scripts/pdf_to_kdf.py package <deck.json> <output-dir>`. The package contains `deck.json`, `manifest.json`, `validation.json`, and Anki-compatible `anki.tsv`.

## Deterministic fallback

Run `scripts/pdf_to_kdf.py draft <pdf> <deck.json> --title <title>` when no model-backed generation is available. This creates source-grounded draft cards from page chunks. Treat them as editorial starting material, not finished study content.

## Guardrails

- Reject encrypted, unreadable, or image-only PDFs unless OCR text is supplied separately.
- Keep one recall target per card. Split compound questions.
- Keep answers concise; move context into `back.explanation` rather than producing paragraph-length answers.
- Preserve a source excerpt of at most 420 characters per card.
- Mark every automated card as `draft` until human review.
- Do not include copyrighted source PDFs or raw source text in a public deck package unless distribution rights are clear.

## Outputs

- `extracted.json`: page-aware text chunks for inspection.
- `deck.json`: canonical KDF v1 draft or published deck.
- `validation.json`: semantic validation result.
- `anki.tsv`: UTF-8 TSV with Front, Back, Tags columns.
- `manifest.json`: package metadata and source checksum.
